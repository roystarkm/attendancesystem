<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$students_count   = (int) $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();
$courses_count    = (int) $pdo->query('SELECT COUNT(*) FROM courses')->fetchColumn();
$users_count      = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$attendance_count = (int) $pdo->query('SELECT COUNT(*) FROM attendance')->fetchColumn();

$logs = $pdo->query('
    SELECT l.*, u.username
    FROM system_logs l
    LEFT JOIN users u ON l.user_id = u.user_id
    ORDER BY l.created_at DESC
    LIMIT 10
')->fetchAll();

$pageTitle = 'Admin Dashboard';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card bg-primary text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Students</h5>
                    <i class="bi bi-mortarboard fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $students_count; ?></h2>
                <a href="students.php" class="text-white text-decoration-underline small">Manage Students &rarr;</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card bg-success text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Courses</h5>
                    <i class="bi bi-book fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $courses_count; ?></h2>
                <a href="courses.php" class="text-white text-decoration-underline small">Manage Courses &rarr;</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card bg-info text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Users</h5>
                    <i class="bi bi-people fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $users_count; ?></h2>
                <a href="users.php" class="text-white text-decoration-underline small">Manage Users &rarr;</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card bg-warning text-dark h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Attendance Logs</h5>
                    <i class="bi bi-clipboard-check fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $attendance_count; ?></h2>
                <a href="reports.php" class="text-dark text-decoration-underline small">Generate Reports &rarr;</a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="bi bi-clock-history me-2"></i>Recent System Activities</h5>
                <a href="users.php" class="btn btn-sm btn-primary">
                    <i class="bi bi-people-fill me-1"></i>Manage Users
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Date / Time</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($logs)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">No recent activity recorded.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td><?php echo e(date('Y-m-d H:i', strtotime($log['created_at']))); ?></td>
                                        <td><?php echo e($log['username'] ?? 'System'); ?></td>
                                        <td><?php echo e($log['action']); ?></td>
                                        <td><code><?php echo e($log['ip_address']); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
