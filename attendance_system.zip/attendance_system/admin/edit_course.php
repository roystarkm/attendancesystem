<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$course_id = (int) ($_GET['id'] ?? 0);
if ($course_id <= 0) {
    setFlash('danger', 'Invalid course selected.');
    redirect('admin/courses.php');
}

$stmt = $pdo->prepare('SELECT * FROM courses WHERE course_id = ?');
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    setFlash('danger', 'Course not found.');
    redirect('admin/courses.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $course_code  = strtoupper(trim($_POST['course_code'] ?? ''));
        $course_name  = trim($_POST['course_name'] ?? '');
        $credit_hours = (int) ($_POST['credit_hours'] ?? 0);
        $program      = trim($_POST['program'] ?? '');
        $lecturer_id  = (int) ($_POST['lecturer_id'] ?? 0);

        if ($course_code === '' || $course_name === '' || $credit_hours < 1 || $credit_hours > 10 || $program === '' || $lecturer_id <= 0) {
            $error = 'Please fill in all fields accurately.';
        } else {
            $check = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE course_code = ? AND course_id != ?');
            $check->execute([$course_code, $course_id]);

            if ((int) $check->fetchColumn() > 0) {
                $error = 'Another course already uses this course code.';
            } else {
                $update = $pdo->prepare('UPDATE courses SET course_code = ?, course_name = ?, credit_hours = ?, program = ?, lecturer_id = ? WHERE course_id = ?');
                if ($update->execute([$course_code, $course_name, $credit_hours, $program, $lecturer_id, $course_id])) {
                    logActivity("Updated course ID: $course_id ($course_code)");
                    setFlash('success', 'Course updated successfully!');
                    redirect('admin/courses.php');
                } else {
                    $error = 'Error updating course.';
                }
            }
        }
    }
}

$lecturers = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'lecturer' ORDER BY full_name ASC")->fetchAll();
$programs  = $pdo->query('SELECT DISTINCT program FROM students ORDER BY program ASC')->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Edit Course';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title mb-0"><i class="bi bi-pencil-square me-2 text-warning"></i>Edit Course Details</h4>
                <a href="courses.php" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Back to Courses
                </a>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <?php echo csrfField(); ?>

                    <div class="mb-3">
                        <label for="course_code" class="form-label">Course Code</label>
                        <input type="text" class="form-control" id="course_code" name="course_code" value="<?php echo e($_POST['course_code'] ?? $course['course_code']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="course_name" class="form-label">Course Name</label>
                        <input type="text" class="form-control" id="course_name" name="course_name" value="<?php echo e($_POST['course_name'] ?? $course['course_name']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="program" class="form-label">Program</label>
                        <input type="text" class="form-control" id="program" name="program" list="courseProgramOptions" value="<?php echo e($_POST['program'] ?? $course['program']); ?>" required>
                        <datalist id="courseProgramOptions">
                            <?php foreach ($programs as $prog): ?>
                                <option value="<?php echo e($prog); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="mb-3">
                        <label for="credit_hours" class="form-label">Credit Hours</label>
                        <input type="number" class="form-control" id="credit_hours" name="credit_hours" min="1" max="10" value="<?php echo (int) ($_POST['credit_hours'] ?? $course['credit_hours']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="lecturer_id" class="form-label">Assign Lecturer</label>
                        <?php $selectedLecturer = (int) ($_POST['lecturer_id'] ?? $course['lecturer_id']); ?>
                        <select class="form-select" id="lecturer_id" name="lecturer_id" required>
                            <option value="">Select Lecturer</option>
                            <?php foreach ($lecturers as $lecturer): ?>
                                <option value="<?php echo (int) $lecturer['user_id']; ?>" <?php echo $selectedLecturer === (int) $lecturer['user_id'] ? 'selected' : ''; ?>>
                                    <?php echo e($lecturer['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i>Update Course
                    </button>
                    <a href="courses.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
