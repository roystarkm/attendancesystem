<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$student_id = (int) ($_GET['id'] ?? 0);
if ($student_id <= 0) {
    setFlash('danger', 'Invalid student selected.');
    redirect('admin/students.php');
}

$stmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    setFlash('danger', 'Student not found.');
    redirect('admin/students.php');
}

// Per-course attendance summary
$courseStmt = $pdo->prepare("
    SELECT
        co.course_id,
        co.course_code,
        co.course_name,
        COUNT(DISTINCT c.class_id) AS total_classes,
        COUNT(DISTINCT CASE WHEN a.student_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
    FROM courses co
    LEFT JOIN classes c ON co.course_id = c.course_id
    LEFT JOIN attendance a ON c.class_id = a.class_id AND a.student_id = ?
    WHERE co.program = ? OR a.student_id IS NOT NULL
    GROUP BY co.course_id, co.course_code, co.course_name
    ORDER BY co.course_code ASC
");
$courseStmt->execute([$student_id, $student_id, $student['program']]);
$courseSummaries = $courseStmt->fetchAll();

// Recent attendance logs
$historyStmt = $pdo->prepare('
    SELECT a.status, a.recorded_at, c.class_date, c.start_time, c.end_time, c.venue, co.course_code, co.course_name
    FROM attendance a
    INNER JOIN classes c ON a.class_id = c.class_id
    INNER JOIN courses co ON c.course_id = co.course_id
    WHERE a.student_id = ?
    ORDER BY c.class_date DESC, c.start_time DESC
    LIMIT 20
');
$historyStmt->execute([$student_id]);
$attendanceHistory = $historyStmt->fetchAll();

$pageTitle = 'Student Details';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-person-badge me-2 text-primary"></i>Student Profile &amp; Attendance</h4>
    <div>
        <a href="edit_student.php?id=<?php echo (int) $student['student_id']; ?>" class="btn btn-warning btn-sm">
            <i class="bi bi-pencil me-1"></i>Edit Student
        </a>
        <a href="students.php" class="btn btn-outline-secondary btn-sm ms-1">
            <i class="bi bi-arrow-left me-1"></i>Back to Students
        </a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-4">
                <small class="text-muted d-block">Full Name</small>
                <strong><?php echo e($student['full_name']); ?></strong>
            </div>
            <div class="col-md-4">
                <small class="text-muted d-block">Registration Number</small>
                <strong><?php echo e($student['registration_number']); ?></strong>
            </div>
            <div class="col-md-4">
                <small class="text-muted d-block">Email</small>
                <span><?php echo e($student['email']); ?></span>
            </div>
            <div class="col-md-6">
                <small class="text-muted d-block">Program</small>
                <span><?php echo e($student['program']); ?></span>
            </div>
            <div class="col-md-6">
                <small class="text-muted d-block">Year of Study</small>
                <span>Year <?php echo (int) $student['year_of_study']; ?></span>
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title mb-0"><i class="bi bi-award me-2 text-success"></i>Course Attendance &amp; Exam Eligibility</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Attended</th>
                        <th>Total Classes</th>
                        <th>Attendance %</th>
                        <th>Eligibility</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($courseSummaries)): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">No courses linked to this student yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($courseSummaries as $row): ?>
                            <?php
                            $total = (int) $row['total_classes'];
                            $attended = (int) $row['attended_classes'];
                            $pct = $total > 0 ? round(($attended / $total) * 100, 2) : 0.0;
                            ?>
                            <tr>
                                <td><?php echo e($row['course_code']); ?></td>
                                <td><?php echo e($row['course_name']); ?></td>
                                <td><?php echo $attended; ?></td>
                                <td><?php echo $total; ?></td>
                                <td><?php echo $pct; ?>%</td>
                                <td>
                                    <?php if ($total === 0): ?>
                                        <span class="badge bg-secondary">No Classes</span>
                                    <?php elseif ($pct >= 75): ?>
                                        <span class="badge bg-success">Eligible</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Eligible</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0"><i class="bi bi-calendar-check me-2 text-primary"></i>Recent Class Attendance History</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Course</th>
                        <th>Time</th>
                        <th>Venue</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($attendanceHistory)): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No attendance records found for this student.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($attendanceHistory as $item): ?>
                            <?php
                            $badgeMap = ['present' => 'success', 'late' => 'warning text-dark', 'absent' => 'danger'];
                            $badgeClass = $badgeMap[$item['status']] ?? 'secondary';
                            ?>
                            <tr>
                                <td><?php echo e(date('Y-m-d', strtotime($item['class_date']))); ?></td>
                                <td><?php echo e($item['course_code'] . ' - ' . $item['course_name']); ?></td>
                                <td><?php echo e(date('H:i', strtotime($item['start_time'])) . ' - ' . date('H:i', strtotime($item['end_time']))); ?></td>
                                <td><?php echo e($item['venue']); ?></td>
                                <td><span class="badge bg-<?php echo $badgeClass; ?> text-uppercase"><?php echo e($item['status']); ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
