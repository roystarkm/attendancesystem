<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$report_type = $_GET['report_type'] ?? 'course';
$course_id   = (int) ($_GET['course_id'] ?? 0);
$student_id  = (int) ($_GET['student_id'] ?? 0);
$start_date  = $_GET['start_date'] ?? date('Y-m-d', strtotime('-1 month'));
$end_date    = $_GET['end_date'] ?? date('Y-m-d');

$report_data  = [];
$report_title = 'Attendance Report';

if ($report_type === 'course' && $course_id > 0) {
    $courseStmt = $pdo->prepare('SELECT * FROM courses WHERE course_id = ?');
    $courseStmt->execute([$course_id]);
    $course_info = $courseStmt->fetch();

    if ($course_info) {
        $totalStmt = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE course_id = ?');
        $totalStmt->execute([$course_id]);
        $total_classes = (int) $totalStmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT
                s.registration_number,
                s.full_name,
                COUNT(DISTINCT CASE WHEN c.course_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
            FROM students s
            LEFT JOIN attendance a ON s.student_id = a.student_id
            LEFT JOIN classes c ON a.class_id = c.class_id AND c.course_id = ?
            WHERE s.program = ? OR c.course_id = ?
            GROUP BY s.student_id, s.registration_number, s.full_name
            ORDER BY s.full_name ASC
        ");
        $stmt->execute([$course_id, $course_id, $course_info['program'], $course_id]);

        foreach ($stmt->fetchAll() as $r) {
            $attended = (int) $r['attended_classes'];
            $r['total_classes'] = $total_classes;
            $r['attendance_percentage'] = $total_classes > 0 ? round(($attended / $total_classes) * 100, 2) : 0.0;
            $report_data[] = $r;
        }
        $report_title = 'Attendance Report for ' . $course_info['course_code'] . ' - ' . $course_info['course_name'];
    }
} elseif ($report_type === 'student' && $student_id > 0) {
    $studentStmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
    $studentStmt->execute([$student_id]);
    $student_info = $studentStmt->fetch();

    if ($student_info) {
        $stmt = $pdo->prepare("
            SELECT
                co.course_code,
                co.course_name,
                COUNT(DISTINCT c.class_id) AS total_classes,
                COUNT(DISTINCT CASE WHEN a.student_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
            FROM courses co
            LEFT JOIN classes c ON co.course_id = c.course_id
            LEFT JOIN attendance a ON c.class_id = a.class_id AND a.student_id = ?
            WHERE co.program = ? OR a.student_id IS NOT NULL
            GROUP BY co.course_id, co.course_code, co.course_name
            ORDER BY co.course_code ASC
        ");
        $stmt->execute([$student_id, $student_id, $student_info['program']]);

        foreach ($stmt->fetchAll() as $r) {
            $total = (int) $r['total_classes'];
            $attended = (int) $r['attended_classes'];
            $r['attendance_percentage'] = $total > 0 ? round(($attended / $total) * 100, 2) : 0.0;
            $report_data[] = $r;
        }
        $report_title = 'Attendance Report for ' . $student_info['full_name'] . ' (' . $student_info['registration_number'] . ')';
    }
} elseif ($report_type === 'date_range') {
    $stmt = $pdo->prepare("
        SELECT
            co.course_code,
            co.course_name,
            c.class_date,
            c.start_time,
            c.end_time,
            c.venue,
            COUNT(CASE WHEN a.status IN ('present', 'late') THEN 1 END) AS present_count,
            COUNT(a.attendance_id) AS total_recorded
        FROM classes c
        INNER JOIN courses co ON c.course_id = co.course_id
        LEFT JOIN attendance a ON c.class_id = a.class_id
        WHERE c.class_date BETWEEN ? AND ?
        GROUP BY c.class_id, co.course_code, co.course_name, c.class_date, c.start_time, c.end_time, c.venue
        ORDER BY c.class_date ASC, c.start_time ASC
    ");
    $stmt->execute([$start_date, $end_date]);

    foreach ($stmt->fetchAll() as $r) {
        $total = (int) $r['total_recorded'];
        $present = (int) $r['present_count'];
        $r['attendance_percentage'] = $total > 0 ? round(($present / $total) * 100, 2) : 0.0;
        $report_data[] = $r;
    }
    $report_title = 'Attendance Summary from ' . date('M j, Y', strtotime($start_date)) . ' to ' . date('M j, Y', strtotime($end_date));
}

logActivity("Exported Excel report ($report_type)");

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="attendance_report_' . date('Ymd_His') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

$colspan = ($report_type === 'date_range') ? 7 : 6;
echo "<table border='1'>";
echo "<tr><th colspan='{$colspan}'>" . e($report_title) . "</th></tr>";

if ($report_type === 'course') {
    echo "<tr>
            <th>Reg No.</th>
            <th>Student Name</th>
            <th>Classes Attended</th>
            <th>Total Classes</th>
            <th>Attendance %</th>
            <th>Eligibility</th>
          </tr>";
    foreach ($report_data as $row) {
        $eligibility = ($row['total_classes'] > 0 && $row['attendance_percentage'] >= 75) ? 'Eligible' : 'Not Eligible';
        echo "<tr>
                <td>" . e($row['registration_number']) . "</td>
                <td>" . e($row['full_name']) . "</td>
                <td>" . (int) $row['attended_classes'] . "</td>
                <td>" . (int) $row['total_classes'] . "</td>
                <td>" . e($row['attendance_percentage']) . "%</td>
                <td>" . e($eligibility) . "</td>
              </tr>";
    }
} elseif ($report_type === 'student') {
    echo "<tr>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Classes Attended</th>
            <th>Total Classes</th>
            <th>Attendance %</th>
            <th>Eligibility</th>
          </tr>";
    foreach ($report_data as $row) {
        $eligibility = ($row['total_classes'] > 0 && $row['attendance_percentage'] >= 75) ? 'Eligible' : 'Not Eligible';
        echo "<tr>
                <td>" . e($row['course_code']) . "</td>
                <td>" . e($row['course_name']) . "</td>
                <td>" . (int) $row['attended_classes'] . "</td>
                <td>" . (int) $row['total_classes'] . "</td>
                <td>" . e($row['attendance_percentage']) . "%</td>
                <td>" . e($eligibility) . "</td>
              </tr>";
    }
} elseif ($report_type === 'date_range') {
    echo "<tr>
            <th>Date</th>
            <th>Course</th>
            <th>Time</th>
            <th>Venue</th>
            <th>Present / Late</th>
            <th>Total Recorded</th>
            <th>Attendance %</th>
          </tr>";
    foreach ($report_data as $row) {
        echo "<tr>
                <td>" . e(date('Y-m-d', strtotime($row['class_date']))) . "</td>
                <td>" . e($row['course_code'] . ' - ' . $row['course_name']) . "</td>
                <td>" . e(date('H:i', strtotime($row['start_time'])) . ' - ' . date('H:i', strtotime($row['end_time']))) . "</td>
                <td>" . e($row['venue']) . "</td>
                <td>" . (int) $row['present_count'] . "</td>
                <td>" . (int) $row['total_recorded'] . "</td>
                <td>" . e($row['attendance_percentage']) . "%</td>
              </tr>";
    }
}

echo "</table>";
exit();
