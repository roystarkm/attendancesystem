<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$error = '';

// Handle user deletion via POST + CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid security token.');
        redirect('admin/users.php');
    }

    $target_id = (int) ($_POST['user_id'] ?? 0);
    if ($target_id === (int) $_SESSION['user_id']) {
        setFlash('danger', 'You cannot delete your own account!');
    } elseif ($target_id > 0) {
        $stmt = $pdo->prepare('DELETE FROM users WHERE user_id = ?');
        if ($stmt->execute([$target_id])) {
            logActivity("Deleted user ID: $target_id");
            setFlash('success', 'User deleted successfully!');
        } else {
            setFlash('danger', 'Error deleting user. Please try again.');
        }
    }
    redirect('admin/users.php');
}

// Handle user creation or update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $username  = trim($_POST['username'] ?? '');
        $full_name = trim($_POST['full_name'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $role      = $_POST['role'] ?? '';
        $user_id   = (int) ($_POST['user_id'] ?? 0);
        $password  = $_POST['password'] ?? '';

        if ($username === '' || $full_name === '' || $email === '' || $role === '') {
            $error = 'Please fill in all required fields.';
        } elseif (!in_array($role, ['admin', 'lecturer'], true)) {
            $error = 'Invalid role selected.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND user_id != ?');
            $stmt->execute([$username, $email, $user_id]);

            if ((int) $stmt->fetchColumn() > 0) {
                $error = 'Username or email already exists.';
            } elseif ($user_id > 0) {
                $sql = 'UPDATE users SET username = ?, full_name = ?, email = ?, role = ?';
                $params = [$username, $full_name, $email, $role];

                if ($password !== '') {
                    if (strlen($password) < 6) {
                        $error = 'Password must be at least 6 characters.';
                    } else {
                        $sql .= ', password = ?';
                        $params[] = password_hash($password, PASSWORD_BCRYPT);
                    }
                }

                $sql .= ' WHERE user_id = ?';
                $params[] = $user_id;

                if ($error === '') {
                    $stmt = $pdo->prepare($sql);
                    if ($stmt->execute($params)) {
                        logActivity("Updated user: $username");
                        setFlash('success', 'User updated successfully!');
                        redirect('admin/users.php');
                    } else {
                        $error = 'Error updating user. Please try again.';
                    }
                }
            } else {
                if ($password === '') {
                    $error = 'Password is required for new users.';
                } elseif (strlen($password) < 6) {
                    $error = 'Password must be at least 6 characters.';
                } else {
                    $stmt = $pdo->prepare('INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)');
                    $hashed = password_hash($password, PASSWORD_BCRYPT);
                    if ($stmt->execute([$username, $hashed, $full_name, $email, $role])) {
                        logActivity("Created new user: $username");
                        setFlash('success', 'User created successfully!');
                        redirect('admin/users.php');
                    } else {
                        $error = 'Error creating user. Please try again.';
                    }
                }
            }
        }
    }
}

$stmt = $pdo->prepare('SELECT user_id, username, full_name, email, role FROM users WHERE user_id != ? ORDER BY role ASC, username ASC');
$stmt->execute([(int) $_SESSION['user_id']]);
$users = $stmt->fetchAll();

$edit_user = null;
if (isset($_GET['edit'])) {
    $edit_id = (int) $_GET['edit'];
    if ($edit_id > 0) {
        $stmt = $pdo->prepare('SELECT user_id, username, full_name, email, role FROM users WHERE user_id = ?');
        $stmt->execute([$edit_id]);
        $edit_user = $stmt->fetch() ?: null;
    }
}

$pageTitle = 'Manage Users';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="bi bi-people me-2 text-primary"></i>Manage Users</h4>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-5">
                        <div class="card mb-4 border">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="bi bi-<?php echo $edit_user ? 'pencil-square' : 'person-plus'; ?> me-2"></i>
                                    <?php echo $edit_user ? 'Edit User Account' : 'Create User Account'; ?>
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="">
                                    <?php echo csrfField(); ?>
                                    <input type="hidden" name="user_id" value="<?php echo (int) ($edit_user['user_id'] ?? $_POST['user_id'] ?? 0); ?>">

                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username *</label>
                                        <input type="text" class="form-control" id="username" name="username"
                                               value="<?php echo e($edit_user['username'] ?? $_POST['username'] ?? ''); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="full_name" class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" id="full_name" name="full_name"
                                               value="<?php echo e($edit_user['full_name'] ?? $_POST['full_name'] ?? ''); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email *</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="<?php echo e($edit_user['email'] ?? $_POST['email'] ?? ''); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="role" class="form-label">Role *</label>
                                        <?php $selectedRole = $edit_user['role'] ?? $_POST['role'] ?? ''; ?>
                                        <select class="form-select" id="role" name="role" required>
                                            <option value="">Select Role</option>
                                            <option value="admin" <?php echo $selectedRole === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                            <option value="lecturer" <?php echo $selectedRole === 'lecturer' ? 'selected' : ''; ?>>Lecturer</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="password" class="form-label">
                                            <?php echo $edit_user ? 'New Password (leave blank to keep current)' : 'Password *'; ?>
                                        </label>
                                        <div class="input-group">
                                            <input type="password" class="form-control" id="password" name="password" <?php echo !$edit_user ? 'required' : ''; ?>>
                                            <button class="btn btn-outline-secondary toggle-password" type="button" aria-label="Show or hide password">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        </div>
                                        <small class="text-muted">Minimum 6 characters</small>
                                    </div>

                                    <button type="submit" name="save_user" class="btn btn-primary">
                                        <i class="bi bi-<?php echo $edit_user ? 'save' : 'check-circle'; ?> me-1"></i>
                                        <?php echo $edit_user ? 'Update User' : 'Create User'; ?>
                                    </button>

                                    <?php if ($edit_user): ?>
                                        <a href="users.php" class="btn btn-secondary">Cancel</a>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-7">
                        <div class="card border">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Registered Users</h5>
                                <input type="text" class="form-control form-control-sm w-50 table-search" data-target="#usersTable" placeholder="Filter users...">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped align-middle mb-0" id="usersTable">
                                        <thead>
                                            <tr>
                                                <th>Username</th>
                                                <th>Name</th>
                                                <th>Role</th>
                                                <th class="text-end">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($users)): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center text-muted py-3">No other users registered.</td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($users as $user): ?>
                                                    <tr>
                                                        <td class="fw-semibold"><?php echo e($user['username']); ?></td>
                                                        <td>
                                                            <div><?php echo e($user['full_name']); ?></div>
                                                            <small class="text-muted"><?php echo e($user['email']); ?></small>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'primary' : 'info text-dark'; ?>">
                                                                <?php echo e(ucfirst($user['role'])); ?>
                                                            </span>
                                                        </td>
                                                        <td class="text-end text-nowrap">
                                                            <a href="users.php?edit=<?php echo (int) $user['user_id']; ?>" class="btn btn-sm btn-warning" title="Edit User">
                                                                <i class="bi bi-pencil me-1"></i>Edit
                                                            </a>
                                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                                <?php echo csrfField(); ?>
                                                                <input type="hidden" name="user_id" value="<?php echo (int) $user['user_id']; ?>">
                                                                <button type="submit" name="delete_user" class="btn btn-sm btn-danger" title="Delete User">
                                                                    <i class="bi bi-trash me-1"></i>Delete
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
