<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$report_type = $_GET['report_type'] ?? 'course';
$course_id   = (int) ($_GET['course_id'] ?? 0);
$student_id  = (int) ($_GET['student_id'] ?? 0);
$start_date  = $_GET['start_date'] ?? date('Y-m-d', strtotime('-1 month'));
$end_date    = $_GET['end_date'] ?? date('Y-m-d');

$courses  = $pdo->query('SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC')->fetchAll();
$students = $pdo->query('SELECT student_id, registration_number, full_name FROM students ORDER BY full_name ASC')->fetchAll();

$report_data  = [];
$report_title = '';
$error        = '';

if (isset($_GET['generate'])) {
    if ($report_type === 'course') {
        if ($course_id <= 0) {
            $error = 'Please select a course to generate the report.';
        } else {
            $courseStmt = $pdo->prepare('SELECT * FROM courses WHERE course_id = ?');
            $courseStmt->execute([$course_id]);
            $course_info = $courseStmt->fetch();

            if ($course_info) {
                $totalStmt = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE course_id = ?');
                $totalStmt->execute([$course_id]);
                $total_classes = (int) $totalStmt->fetchColumn();

                $stmt = $pdo->prepare("
                    SELECT
                        s.student_id,
                        s.registration_number,
                        s.full_name,
                        COUNT(DISTINCT CASE WHEN c.course_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
                    FROM students s
                    LEFT JOIN attendance a ON s.student_id = a.student_id
                    LEFT JOIN classes c ON a.class_id = c.class_id AND c.course_id = ?
                    WHERE s.program = ? OR c.course_id = ?
                    GROUP BY s.student_id, s.registration_number, s.full_name
                    ORDER BY s.full_name ASC
                ");
                $stmt->execute([$course_id, $course_id, $course_info['program'], $course_id]);
                $rows = $stmt->fetchAll();

                foreach ($rows as $r) {
                    $attended = (int) $r['attended_classes'];
                    $r['total_classes'] = $total_classes;
                    $r['attendance_percentage'] = $total_classes > 0 ? round(($attended / $total_classes) * 100, 2) : 0.0;
                    $report_data[] = $r;
                }

                $report_title = 'Attendance Report for ' . $course_info['course_code'] . ' - ' . $course_info['course_name'];
            }
        }
    } elseif ($report_type === 'student') {
        if ($student_id <= 0) {
            $error = 'Please select a student to generate the report.';
        } else {
            $studentStmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
            $studentStmt->execute([$student_id]);
            $student_info = $studentStmt->fetch();

            if ($student_info) {
                $stmt = $pdo->prepare("
                    SELECT
                        co.course_id,
                        co.course_code,
                        co.course_name,
                        COUNT(DISTINCT c.class_id) AS total_classes,
                        COUNT(DISTINCT CASE WHEN a.student_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
                    FROM courses co
                    LEFT JOIN classes c ON co.course_id = c.course_id
                    LEFT JOIN attendance a ON c.class_id = a.class_id AND a.student_id = ?
                    WHERE co.program = ? OR a.student_id IS NOT NULL
                    GROUP BY co.course_id, co.course_code, co.course_name
                    ORDER BY co.course_code ASC
                ");
                $stmt->execute([$student_id, $student_id, $student_info['program']]);
                $rows = $stmt->fetchAll();

                foreach ($rows as $r) {
                    $total = (int) $r['total_classes'];
                    $attended = (int) $r['attended_classes'];
                    $r['attendance_percentage'] = $total > 0 ? round(($attended / $total) * 100, 2) : 0.0;
                    $report_data[] = $r;
                }

                $report_title = 'Attendance Report for ' . $student_info['full_name'] . ' (' . $student_info['registration_number'] . ')';
            }
        }
    } elseif ($report_type === 'date_range') {
        $stmt = $pdo->prepare("
            SELECT
                c.class_id,
                co.course_code,
                co.course_name,
                c.class_date,
                c.start_time,
                c.end_time,
                c.venue,
                COUNT(CASE WHEN a.status IN ('present', 'late') THEN 1 END) AS present_count,
                COUNT(a.attendance_id) AS total_recorded
            FROM classes c
            INNER JOIN courses co ON c.course_id = co.course_id
            LEFT JOIN attendance a ON c.class_id = a.class_id
            WHERE c.class_date BETWEEN ? AND ?
            GROUP BY c.class_id, co.course_code, co.course_name, c.class_date, c.start_time, c.end_time, c.venue
            ORDER BY c.class_date DESC, c.start_time DESC
        ");
        $stmt->execute([$start_date, $end_date]);
        $rows = $stmt->fetchAll();

        foreach ($rows as $r) {
            $total = (int) $r['total_recorded'];
            $present = (int) $r['present_count'];
            $r['attendance_percentage'] = $total > 0 ? round(($present / $total) * 100, 2) : 0.0;
            $report_data[] = $r;
        }

        $report_title = 'Attendance Summary from ' . date('M j, Y', strtotime($start_date)) . ' to ' . date('M j, Y', strtotime($end_date));
    }
}

$pageTitle = 'Attendance Reports';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="bi bi-bar-chart-line me-2 text-primary"></i>Attendance &amp; Eligibility Reports</h4>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <form method="GET" action="">
                    <div class="row g-3 mb-4">
                        <div class="col-md-3">
                            <label for="reportTypeSelect" class="form-label">Report Type</label>
                            <select class="form-select" name="report_type" id="reportTypeSelect">
                                <option value="course" <?php echo $report_type === 'course' ? 'selected' : ''; ?>>By Course</option>
                                <option value="student" <?php echo $report_type === 'student' ? 'selected' : ''; ?>>By Student</option>
                                <option value="date_range" <?php echo $report_type === 'date_range' ? 'selected' : ''; ?>>By Date Range</option>
                            </select>
                        </div>

                        <div class="col-md-5" id="courseSelectDiv" <?php echo $report_type !== 'course' ? 'style="display:none;"' : ''; ?>>
                            <label for="course_id" class="form-label">Select Course</label>
                            <select class="form-select" name="course_id" id="course_id">
                                <option value="">-- Choose Course --</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo (int) $course['course_id']; ?>" <?php echo $course_id === (int) $course['course_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($course['course_code'] . ' - ' . $course['course_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-5" id="studentSelectDiv" <?php echo $report_type !== 'student' ? 'style="display:none;"' : ''; ?>>
                            <label for="student_id" class="form-label">Select Student</label>
                            <select class="form-select" name="student_id" id="student_id">
                                <option value="">-- Choose Student --</option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo (int) $student['student_id']; ?>" <?php echo $student_id === (int) $student['student_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($student['registration_number'] . ' - ' . $student['full_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-5" id="dateRangeDiv" <?php echo $report_type !== 'date_range' ? 'style="display:none;"' : ''; ?>>
                            <div class="row g-2">
                                <div class="col-6">
                                    <label for="start_date" class="form-label">Start Date</label>
                                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e($start_date); ?>">
                                </div>
                                <div class="col-6">
                                    <label for="end_date" class="form-label">End Date</label>
                                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo e($end_date); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 align-self-end d-flex gap-2">
                            <button type="submit" name="generate" value="1" class="btn btn-primary">
                                <i class="bi bi-file-earmark-text me-1"></i>Generate Report
                            </button>

                            <?php if (!empty($report_data)): ?>
                                <a href="export_report.php?<?php echo e(http_build_query($_GET)); ?>" class="btn btn-success">
                                    <i class="bi bi-file-earmark-excel me-1"></i>Export Excel
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>

                <?php if (!empty($report_data)): ?>
                    <div class="card border mt-3">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><?php echo e($report_title); ?></h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                                <i class="bi bi-printer me-1"></i>Print Report
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <?php if ($report_type === 'course'): ?>
                                                <th>Reg No.</th>
                                                <th>Student Name</th>
                                                <th>Classes Attended</th>
                                                <th>Total Classes</th>
                                                <th>Attendance %</th>
                                                <th>Eligibility (75%)</th>
                                            <?php elseif ($report_type === 'student'): ?>
                                                <th>Course Code</th>
                                                <th>Course Name</th>
                                                <th>Classes Attended</th>
                                                <th>Total Classes</th>
                                                <th>Attendance %</th>
                                                <th>Eligibility (75%)</th>
                                            <?php elseif ($report_type === 'date_range'): ?>
                                                <th>Date</th>
                                                <th>Course</th>
                                                <th>Time</th>
                                                <th>Venue</th>
                                                <th>Present / Late</th>
                                                <th>Total Recorded</th>
                                                <th>Attendance %</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $row): ?>
                                            <tr>
                                                <?php if ($report_type === 'course'): ?>
                                                    <td><?php echo e($row['registration_number']); ?></td>
                                                    <td><?php echo e($row['full_name']); ?></td>
                                                    <td><?php echo (int) $row['attended_classes']; ?></td>
                                                    <td><?php echo (int) $row['total_classes']; ?></td>
                                                    <td><?php echo e($row['attendance_percentage']); ?>%</td>
                                                    <td>
                                                        <?php if ((int) $row['total_classes'] === 0): ?>
                                                            <span class="badge bg-secondary">No Classes</span>
                                                        <?php elseif ($row['attendance_percentage'] >= 75): ?>
                                                            <span class="badge bg-success">Eligible</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Not Eligible</span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php elseif ($report_type === 'student'): ?>
                                                    <td><?php echo e($row['course_code']); ?></td>
                                                    <td><?php echo e($row['course_name']); ?></td>
                                                    <td><?php echo (int) $row['attended_classes']; ?></td>
                                                    <td><?php echo (int) $row['total_classes']; ?></td>
                                                    <td><?php echo e($row['attendance_percentage']); ?>%</td>
                                                    <td>
                                                        <?php if ((int) $row['total_classes'] === 0): ?>
                                                            <span class="badge bg-secondary">No Classes</span>
                                                        <?php elseif ($row['attendance_percentage'] >= 75): ?>
                                                            <span class="badge bg-success">Eligible</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Not Eligible</span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php elseif ($report_type === 'date_range'): ?>
                                                    <td><?php echo e(date('Y-m-d', strtotime($row['class_date']))); ?></td>
                                                    <td><?php echo e($row['course_code'] . ' - ' . $row['course_name']); ?></td>
                                                    <td><?php echo e(date('H:i', strtotime($row['start_time'])) . ' - ' . date('H:i', strtotime($row['end_time']))); ?></td>
                                                    <td><?php echo e($row['venue']); ?></td>
                                                    <td><?php echo (int) $row['present_count']; ?></td>
                                                    <td><?php echo (int) $row['total_recorded']; ?></td>
                                                    <td><?php echo e($row['attendance_percentage']); ?>%</td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php elseif (isset($_GET['generate']) && $error === ''): ?>
                    <div class="alert alert-warning mt-3">No attendance records found for the selected criteria.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('reportTypeSelect').addEventListener('change', function () {
    const type = this.value;
    document.getElementById('courseSelectDiv').style.display = (type === 'course') ? 'block' : 'none';
    document.getElementById('studentSelectDiv').style.display = (type === 'student') ? 'block' : 'none';
    document.getElementById('dateRangeDiv').style.display = (type === 'date_range') ? 'block' : 'none';
});
</script>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
