<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$error = '';

// Handle course deletion via POST + CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_course'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid security token.');
        redirect('admin/courses.php');
    }

    $course_id = (int) ($_POST['course_id'] ?? 0);
    if ($course_id > 0) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM classes WHERE course_id = ?')->execute([$course_id]);
            $pdo->prepare('DELETE FROM courses WHERE course_id = ?')->execute([$course_id]);
            $pdo->commit();

            logActivity("Deleted course ID: $course_id");
            setFlash('success', 'Course deleted successfully!');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('danger', 'Error deleting course: ' . $e->getMessage());
        }
    }
    redirect('admin/courses.php');
}

// Handle adding a new course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_course'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $course_code  = strtoupper(trim($_POST['course_code'] ?? ''));
        $course_name  = trim($_POST['course_name'] ?? '');
        $credit_hours = (int) ($_POST['credit_hours'] ?? 0);
        $program      = trim($_POST['program'] ?? '');
        $lecturer_id  = (int) ($_POST['lecturer_id'] ?? 0);

        if ($course_code === '' || $course_name === '' || $credit_hours < 1 || $credit_hours > 10 || $program === '' || $lecturer_id <= 0) {
            $error = 'Please fill in all fields accurately.';
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE course_code = ?');
            $stmt->execute([$course_code]);

            if ((int) $stmt->fetchColumn() > 0) {
                $error = 'Course with this code already exists.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO courses (course_code, course_name, credit_hours, program, lecturer_id) VALUES (?, ?, ?, ?, ?)');
                if ($stmt->execute([$course_code, $course_name, $credit_hours, $program, $lecturer_id])) {
                    logActivity("Added new course: $course_code");
                    setFlash('success', 'Course created successfully!');
                    redirect('admin/courses.php');
                } else {
                    $error = 'Error adding course. Please try again.';
                }
            }
        }
    }
}

$courses = $pdo->query('
    SELECT c.*, u.full_name AS lecturer_name
    FROM courses c
    LEFT JOIN users u ON c.lecturer_id = u.user_id
    ORDER BY c.course_code ASC
')->fetchAll();

$lecturers = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'lecturer' ORDER BY full_name ASC")->fetchAll();
$programs  = $pdo->query('SELECT DISTINCT program FROM students ORDER BY program ASC')->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Manage Courses';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h4 class="card-title mb-0"><i class="bi bi-book me-2 text-primary"></i>Manage Courses</h4>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control form-control-sm table-search" data-target="#coursesTable" placeholder="Filter courses...">
                    <button class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                        <i class="bi bi-plus-circle me-1"></i>Create Course
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped align-middle" id="coursesTable">
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Program</th>
                                <th>Credit Hours</th>
                                <th>Lecturer</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($courses)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-3">No courses found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($courses as $course): ?>
                                    <tr>
                                        <td class="fw-semibold"><?php echo e($course['course_code']); ?></td>
                                        <td><?php echo e($course['course_name']); ?></td>
                                        <td><?php echo e($course['program']); ?></td>
                                        <td><?php echo (int) $course['credit_hours']; ?></td>
                                        <td><?php echo e($course['lecturer_name'] ?? 'Not assigned'); ?></td>
                                        <td class="text-end text-nowrap">
                                            <a href="course_details.php?id=<?php echo (int) $course['course_id']; ?>" class="btn btn-sm btn-info text-white" title="View Course Details">
                                                <i class="bi bi-eye me-1"></i>View
                                            </a>
                                            <a href="edit_course.php?id=<?php echo (int) $course['course_id']; ?>" class="btn btn-sm btn-warning" title="Edit Course">
                                                <i class="bi bi-pencil me-1"></i>Edit
                                            </a>
                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this course and its classes?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="course_id" value="<?php echo (int) $course['course_id']; ?>">
                                                <button type="submit" name="delete_course" class="btn btn-sm btn-danger" title="Delete Course">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1" aria-labelledby="addCourseModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCourseModalLabel"><i class="bi bi-journal-plus me-2"></i>Create New Course</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="">
                <?php echo csrfField(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="course_code" class="form-label">Course Code</label>
                        <input type="text" class="form-control" id="course_code" name="course_code" placeholder="e.g. BIT2105" required>
                    </div>
                    <div class="mb-3">
                        <label for="course_name" class="form-label">Course Name</label>
                        <input type="text" class="form-control" id="course_name" name="course_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="program" class="form-label">Program</label>
                        <input type="text" class="form-control" id="program" name="program" list="courseProgramOptions" placeholder="e.g. Bachelor of Information Technology" required>
                        <datalist id="courseProgramOptions">
                            <?php foreach ($programs as $prog): ?>
                                <option value="<?php echo e($prog); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    <div class="mb-3">
                        <label for="credit_hours" class="form-label">Credit Hours</label>
                        <input type="number" class="form-control" id="credit_hours" name="credit_hours" min="1" max="10" value="3" required>
                    </div>
                    <div class="mb-3">
                        <label for="lecturer_id" class="form-label">Assign Lecturer</label>
                        <select class="form-select" id="lecturer_id" name="lecturer_id" required>
                            <option value="">Select Lecturer</option>
                            <?php foreach ($lecturers as $lecturer): ?>
                                <option value="<?php echo (int) $lecturer['user_id']; ?>"><?php echo e($lecturer['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="add_course">
                        <i class="bi bi-check-circle me-1"></i>Save Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
