<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$error = '';

// Handle student deletion via POST + CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_student'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid security token.');
        redirect('admin/students.php');
    }

    $student_id = (int) ($_POST['student_id'] ?? 0);
    if ($student_id > 0) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM attendance WHERE student_id = ?')->execute([$student_id]);
            $pdo->prepare('DELETE FROM students WHERE student_id = ?')->execute([$student_id]);
            $pdo->commit();

            logActivity("Deleted student ID: $student_id");
            setFlash('success', 'Student deleted successfully!');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('danger', 'Error deleting student: ' . $e->getMessage());
        }
    }
    redirect('admin/students.php');
}

// Handle adding a new student
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $reg_number    = trim($_POST['reg_number'] ?? '');
        $full_name     = trim($_POST['full_name'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $program       = trim($_POST['program'] ?? '');
        $year_of_study = (int) ($_POST['year_of_study'] ?? 0);

        if ($reg_number === '' || $full_name === '' || $email === '' || $program === '' || $year_of_study < 1 || $year_of_study > 5) {
            $error = 'Please fill in all fields accurately.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM students WHERE registration_number = ? OR email = ?');
            $stmt->execute([$reg_number, $email]);

            if ((int) $stmt->fetchColumn() > 0) {
                $error = 'A student with this registration number or email already exists.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO students (registration_number, full_name, email, program, year_of_study) VALUES (?, ?, ?, ?, ?)');
                if ($stmt->execute([$reg_number, $full_name, $email, $program, $year_of_study])) {
                    logActivity("Added new student: $reg_number");
                    setFlash('success', 'Student registered successfully!');
                    redirect('admin/students.php');
                } else {
                    $error = 'Error adding student. Please try again.';
                }
            }
        }
    }
}

$students = $pdo->query('SELECT * FROM students ORDER BY full_name ASC')->fetchAll();
$programs = $pdo->query('SELECT DISTINCT program FROM students ORDER BY program ASC')->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Manage Students';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h4 class="card-title mb-0"><i class="bi bi-mortarboard me-2 text-primary"></i>Manage Students</h4>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control form-control-sm table-search" data-target="#studentsTable" placeholder="Filter students...">
                    <button class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                        <i class="bi bi-plus-circle me-1"></i>Register Student
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped align-middle" id="studentsTable">
                        <thead>
                            <tr>
                                <th>Reg No.</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Program</th>
                                <th>Year</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($students)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-3">No students found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($students as $student): ?>
                                    <tr>
                                        <td class="fw-semibold"><?php echo e($student['registration_number']); ?></td>
                                        <td><?php echo e($student['full_name']); ?></td>
                                        <td><?php echo e($student['email']); ?></td>
                                        <td><?php echo e($student['program']); ?></td>
                                        <td>Year <?php echo (int) $student['year_of_study']; ?></td>
                                        <td class="text-end text-nowrap">
                                            <a href="student_details.php?id=<?php echo (int) $student['student_id']; ?>" class="btn btn-sm btn-info text-white" title="View Student Profile">
                                                <i class="bi bi-eye me-1"></i>View
                                            </a>
                                            <a href="edit_student.php?id=<?php echo (int) $student['student_id']; ?>" class="btn btn-sm btn-warning" title="Edit Student">
                                                <i class="bi bi-pencil me-1"></i>Edit
                                            </a>
                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this student and all their attendance records?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="student_id" value="<?php echo (int) $student['student_id']; ?>">
                                                <button type="submit" name="delete_student" class="btn btn-sm btn-danger" title="Delete Student">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addStudentModalLabel"><i class="bi bi-person-plus me-2"></i>Register New Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="">
                <?php echo csrfField(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="reg_number" class="form-label">Registration Number</label>
                        <input type="text" class="form-control" id="reg_number" name="reg_number" placeholder="e.g. 24/1/314/D/005" required>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="program" class="form-label">Program</label>
                        <input type="text" class="form-control" id="program" name="program" list="programOptions" placeholder="e.g. Bachelor of Information Technology" required>
                        <datalist id="programOptions">
                            <?php foreach ($programs as $prog): ?>
                                <option value="<?php echo e($prog); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    <div class="mb-3">
                        <label for="year_of_study" class="form-label">Year of Study</label>
                        <select class="form-select" id="year_of_study" name="year_of_study" required>
                            <option value="1">Year 1</option>
                            <option value="2">Year 2</option>
                            <option value="3">Year 3</option>
                            <option value="4">Year 4</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="add_student">
                        <i class="bi bi-check-circle me-1"></i>Save Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
