<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$student_id = (int) ($_GET['id'] ?? 0);
if ($student_id <= 0) {
    setFlash('danger', 'Invalid student selected.');
    redirect('admin/students.php');
}

$stmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    setFlash('danger', 'Student not found.');
    redirect('admin/students.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $reg_number    = trim($_POST['reg_number'] ?? '');
        $full_name     = trim($_POST['full_name'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $program       = trim($_POST['program'] ?? '');
        $year_of_study = (int) ($_POST['year_of_study'] ?? 0);

        if ($reg_number === '' || $full_name === '' || $email === '' || $program === '' || $year_of_study < 1 || $year_of_study > 5) {
            $error = 'Please fill in all fields accurately.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } else {
            $check = $pdo->prepare('SELECT COUNT(*) FROM students WHERE (registration_number = ? OR email = ?) AND student_id != ?');
            $check->execute([$reg_number, $email, $student_id]);

            if ((int) $check->fetchColumn() > 0) {
                $error = 'Another student already uses that registration number or email.';
            } else {
                $update = $pdo->prepare('UPDATE students SET registration_number = ?, full_name = ?, email = ?, program = ?, year_of_study = ? WHERE student_id = ?');
                if ($update->execute([$reg_number, $full_name, $email, $program, $year_of_study, $student_id])) {
                    logActivity("Updated student ID: $student_id ($reg_number)");
                    setFlash('success', 'Student details updated successfully!');
                    redirect('admin/students.php');
                } else {
                    $error = 'Error updating student details.';
                }
            }
        }
    }
}

$programs = $pdo->query('SELECT DISTINCT program FROM students ORDER BY program ASC')->fetchAll(PDO::FETCH_COLUMN);

$pageTitle = 'Edit Student';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title mb-0"><i class="bi bi-pencil-square me-2 text-warning"></i>Edit Student Profile</h4>
                <a href="students.php" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Back to Students
                </a>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <?php echo csrfField(); ?>

                    <div class="mb-3">
                        <label for="reg_number" class="form-label">Registration Number</label>
                        <input type="text" class="form-control" id="reg_number" name="reg_number" value="<?php echo e($_POST['reg_number'] ?? $student['registration_number']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($_POST['full_name'] ?? $student['full_name']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($_POST['email'] ?? $student['email']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="program" class="form-label">Program</label>
                        <input type="text" class="form-control" id="program" name="program" list="programOptions" value="<?php echo e($_POST['program'] ?? $student['program']); ?>" required>
                        <datalist id="programOptions">
                            <?php foreach ($programs as $prog): ?>
                                <option value="<?php echo e($prog); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="mb-3">
                        <label for="year_of_study" class="form-label">Year of Study</label>
                        <?php $selectedYear = (int) ($_POST['year_of_study'] ?? $student['year_of_study']); ?>
                        <select class="form-select" id="year_of_study" name="year_of_study" required>
                            <?php for ($y = 1; $y <= 4; $y++): ?>
                                <option value="<?php echo $y; ?>" <?php echo $selectedYear === $y ? 'selected' : ''; ?>>Year <?php echo $y; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i>Update Student
                    </button>
                    <a href="students.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
