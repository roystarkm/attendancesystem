<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['admin']);

$course_id = (int) ($_GET['id'] ?? 0);
if ($course_id <= 0) {
    setFlash('danger', 'Invalid course selected.');
    redirect('admin/courses.php');
}

$stmt = $pdo->prepare('
    SELECT c.*, u.full_name AS lecturer_name, u.email AS lecturer_email
    FROM courses c
    LEFT JOIN users u ON c.lecturer_id = u.user_id
    WHERE c.course_id = ?
');
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    setFlash('danger', 'Course not found.');
    redirect('admin/courses.php');
}

// Scheduled/held classes for this course
$classStmt = $pdo->prepare("
    SELECT c.*,
           COUNT(CASE WHEN a.status IN ('present', 'late') THEN 1 END) AS present_count,
           COUNT(a.attendance_id) AS recorded_count
    FROM classes c
    LEFT JOIN attendance a ON c.class_id = a.class_id
    WHERE c.course_id = ?
    GROUP BY c.class_id
    ORDER BY c.class_date DESC, c.start_time DESC
");
$classStmt->execute([$course_id]);
$classes = $classStmt->fetchAll();

// Student attendance breakdown for this course
$totalClasses = count($classes);
$studentStmt = $pdo->prepare("
    SELECT s.student_id, s.registration_number, s.full_name,
           COUNT(DISTINCT CASE WHEN c.course_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
    FROM students s
    LEFT JOIN attendance a ON s.student_id = a.student_id
    LEFT JOIN classes c ON a.class_id = c.class_id AND c.course_id = ?
    WHERE s.program = ? OR c.course_id = ?
    GROUP BY s.student_id, s.registration_number, s.full_name
    ORDER BY s.full_name ASC
");
$studentStmt->execute([$course_id, $course_id, $course['program'], $course_id]);
$studentStats = $studentStmt->fetchAll();

$pageTitle = 'Course Details';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-journal-text me-2 text-primary"></i><?php echo e($course['course_code'] . ' - ' . $course['course_name']); ?></h4>
    <div>
        <a href="edit_course.php?id=<?php echo (int) $course['course_id']; ?>" class="btn btn-warning btn-sm">
            <i class="bi bi-pencil me-1"></i>Edit Course
        </a>
        <a href="courses.php" class="btn btn-outline-secondary btn-sm ms-1">
            <i class="bi bi-arrow-left me-1"></i>Back to Courses
        </a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <small class="text-muted d-block">Course Code</small>
                <strong><?php echo e($course['course_code']); ?></strong>
            </div>
            <div class="col-md-3">
                <small class="text-muted d-block">Credit Hours</small>
                <strong><?php echo (int) $course['credit_hours']; ?> CU</strong>
            </div>
            <div class="col-md-3">
                <small class="text-muted d-block">Program</small>
                <span><?php echo e($course['program']); ?></span>
            </div>
            <div class="col-md-3">
                <small class="text-muted d-block">Assigned Lecturer</small>
                <span><?php echo e($course['lecturer_name'] ?? 'Not assigned'); ?></span>
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title mb-0"><i class="bi bi-calendar-event me-2 text-primary"></i>Class Sessions Held (<?php echo $totalClasses; ?>)</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Venue</th>
                        <th>Topic</th>
                        <th>Present / Recorded</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($classes)): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No classes scheduled for this course yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($classes as $cl): ?>
                            <tr>
                                <td><?php echo e(date('Y-m-d', strtotime($cl['class_date']))); ?></td>
                                <td><?php echo e(date('H:i', strtotime($cl['start_time'])) . ' - ' . date('H:i', strtotime($cl['end_time']))); ?></td>
                                <td><?php echo e($cl['venue']); ?></td>
                                <td><?php echo e($cl['topic'] ?? '-'); ?></td>
                                <td><?php echo (int) $cl['present_count'] . ' / ' . (int) $cl['recorded_count']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0"><i class="bi bi-award me-2 text-success"></i>Student Attendance &amp; Eligibility</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>Reg No.</th>
                        <th>Student Name</th>
                        <th>Attended</th>
                        <th>Total Classes</th>
                        <th>Attendance %</th>
                        <th>Eligibility</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($studentStats)): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">No students found for this course program.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($studentStats as $st): ?>
                            <?php
                            $attended = (int) $st['attended_classes'];
                            $pct = $totalClasses > 0 ? round(($attended / $totalClasses) * 100, 2) : 0.0;
                            ?>
                            <tr>
                                <td><?php echo e($st['registration_number']); ?></td>
                                <td><?php echo e($st['full_name']); ?></td>
                                <td><?php echo $attended; ?></td>
                                <td><?php echo $totalClasses; ?></td>
                                <td><?php echo $pct; ?>%</td>
                                <td>
                                    <?php if ($totalClasses === 0): ?>
                                        <span class="badge bg-secondary">Pending</span>
                                    <?php elseif ($pct >= 75): ?>
                                        <span class="badge bg-success">Eligible</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Eligible</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
