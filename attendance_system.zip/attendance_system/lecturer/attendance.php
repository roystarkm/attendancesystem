<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['lecturer']);

$lecturer_id = (int) $_SESSION['user_id'];
$error = '';
$class_id = (int) ($_GET['class_id'] ?? $_POST['class_id'] ?? 0);
$selected_programs = $_GET['program'] ?? [];
if (!is_array($selected_programs)) {
    $selected_programs = [$selected_programs];
}

// Handle saving attendance records
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_attendance'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } elseif ($class_id <= 0) {
        $error = 'Please select a valid class.';
    } else {
        $verify = $pdo->prepare('SELECT class_id FROM classes WHERE class_id = ? AND lecturer_id = ?');
        $verify->execute([$class_id, $lecturer_id]);

        if (!$verify->fetch()) {
            $error = 'You are not authorized to record attendance for this class.';
        } else {
            $attendance_data = $_POST['attendance'] ?? [];
            $allowedStatuses = ['present', 'absent', 'late'];

            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare('
                    INSERT INTO attendance (class_id, student_id, status, recorded_by)
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE status = VALUES(status), recorded_by = VALUES(recorded_by)
                ');

                foreach ($attendance_data as $student_id => $status) {
                    $sid = (int) $student_id;
                    if ($sid > 0 && in_array($status, $allowedStatuses, true)) {
                        $stmt->execute([$class_id, $sid, $status, $lecturer_id]);
                    }
                }

                $pdo->commit();
                logActivity("Recorded attendance for class ID: $class_id");
                setFlash('success', 'Attendance saved successfully!');

                $queryParams = ['class_id' => $class_id];
                if (!empty($_POST['loaded_programs']) && is_array($_POST['loaded_programs'])) {
                    $queryParams['program'] = $_POST['loaded_programs'];
                }
                redirect('lecturer/attendance.php?' . http_build_query($queryParams));
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Error recording attendance: ' . $e->getMessage();
            }
        }
    }
}

$class = null;
if ($class_id > 0) {
    $stmt = $pdo->prepare('
        SELECT c.*, co.course_code, co.course_name, co.program AS course_program
        FROM classes c
        INNER JOIN courses co ON c.course_id = co.course_id
        WHERE c.class_id = ? AND c.lecturer_id = ?
    ');
    $stmt->execute([$class_id, $lecturer_id]);
    $class = $stmt->fetch();

    if (!$class) {
        $error = 'Class not found or you are not authorized to view it.';
        $class_id = 0;
    } elseif (empty($selected_programs) && !empty($class['course_program'])) {
        $selected_programs = [$class['course_program']];
    }
}

$programs = $pdo->query('SELECT DISTINCT program FROM students ORDER BY program ASC')->fetchAll(PDO::FETCH_COLUMN);

$students = [];
$attendance_records = [];
if ($class_id > 0 && !empty($selected_programs)) {
    $placeholders = implode(',', array_fill(0, count($selected_programs), '?'));
    $stmt = $pdo->prepare("SELECT * FROM students WHERE program IN ($placeholders) ORDER BY full_name ASC");
    $stmt->execute(array_values($selected_programs));
    $students = $stmt->fetchAll();

    $attStmt = $pdo->prepare('SELECT student_id, status FROM attendance WHERE class_id = ?');
    $attStmt->execute([$class_id]);
    $attendance_records = $attStmt->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
}

$lcStmt = $pdo->prepare('
    SELECT c.class_id, c.class_date, c.start_time, co.course_code, co.course_name
    FROM classes c
    INNER JOIN courses co ON c.course_id = co.course_id
    WHERE c.lecturer_id = ?
    ORDER BY c.class_date DESC, c.start_time DESC
');
$lcStmt->execute([$lecturer_id]);
$lecturer_classes = $lcStmt->fetchAll();

$pageTitle = 'Record Attendance';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="bi bi-clipboard-check me-2 text-primary"></i>Record Class Attendance</h4>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <form method="GET" action="" class="row g-3 align-items-start mb-4 p-3 bg-light rounded border">
                    <div class="col-md-5">
                        <label for="class_id" class="form-label fw-semibold">1. Select Class Session</label>
                        <select class="form-select" id="class_id" name="class_id" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($lecturer_classes as $lc): ?>
                                <option value="<?php echo (int) $lc['class_id']; ?>" <?php echo $class_id === (int) $lc['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo e(date('Y-m-d', strtotime($lc['class_date'])) . ' (' . date('H:i', strtotime($lc['start_time'])) . ') - ' . $lc['course_code']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-5">
                        <label class="form-label fw-semibold">2. Filter Student Programs</label>
                        <?php if (empty($programs)): ?>
                            <p class="text-muted small mb-0">No student programs available.</p>
                        <?php else: ?>
                            <?php foreach ($programs as $idx => $program): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="program[]" id="prog_<?php echo $idx; ?>"
                                           value="<?php echo e($program); ?>" <?php echo in_array($program, $selected_programs, true) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="prog_<?php echo $idx; ?>"><?php echo e($program); ?></label>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-2 align-self-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-people me-1"></i>Load Students
                        </button>
                    </div>
                </form>

                <?php if ($class_id > 0 && !empty($selected_programs)): ?>
                    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
                        <div>
                            <h5 class="mb-0"><?php echo e($class['course_code'] . ' - ' . $class['course_name']); ?></h5>
                            <small class="text-muted">
                                Date: <?php echo e(date('Y-m-d', strtotime($class['class_date']))); ?> |
                                Venue: <?php echo e($class['venue']); ?> |
                                Students Loaded: <?php echo count($students); ?>
                            </small>
                        </div>
                        <?php if (!empty($students)): ?>
                            <div class="btn-group btn-group-sm" role="group" aria-label="Bulk status controls">
                                <button type="button" class="btn btn-outline-success" onclick="setAllAttendance('present')">
                                    <i class="bi bi-check-all me-1"></i>Mark All Present
                                </button>
                                <button type="button" class="btn btn-outline-danger" onclick="setAllAttendance('absent')">
                                    <i class="bi bi-x-circle me-1"></i>Mark All Absent
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (empty($students)): ?>
                        <div class="alert alert-info">No students found in the selected program(s).</div>
                    <?php else: ?>
                        <form method="POST" action="">
                            <?php echo csrfField(); ?>
                            <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                            <?php foreach ($selected_programs as $sp): ?>
                                <input type="hidden" name="loaded_programs[]" value="<?php echo e($sp); ?>">
                            <?php endforeach; ?>

                            <div class="table-responsive">
                                <table class="table table-striped align-middle">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Reg No.</th>
                                            <th>Student Name</th>
                                            <th>Program</th>
                                            <th style="width: 180px;">Attendance Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($students as $index => $student): ?>
                                            <?php $currentStatus = $attendance_records[$student['student_id']] ?? 'present'; ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td class="fw-semibold"><?php echo e($student['registration_number']); ?></td>
                                                <td><?php echo e($student['full_name']); ?></td>
                                                <td><small class="text-muted"><?php echo e($student['program']); ?></small></td>
                                                <td>
                                                    <select class="form-select form-select-sm attendance-select" name="attendance[<?php echo (int) $student['student_id']; ?>]">
                                                        <option value="present" <?php echo $currentStatus === 'present' ? 'selected' : ''; ?>>Present</option>
                                                        <option value="late" <?php echo $currentStatus === 'late' ? 'selected' : ''; ?>>Late</option>
                                                        <option value="absent" <?php echo $currentStatus === 'absent' ? 'selected' : ''; ?>>Absent</option>
                                                    </select>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <button type="submit" name="submit_attendance" class="btn btn-success mt-3">
                                <i class="bi bi-save me-1"></i>Save Attendance
                            </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
