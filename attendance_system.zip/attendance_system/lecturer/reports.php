<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['lecturer']);

$lecturer_id = (int) $_SESSION['user_id'];
$report_type = $_GET['report_type'] ?? 'course';
$course_id   = (int) ($_GET['course_id'] ?? 0);
$student_id  = (int) ($_GET['student_id'] ?? 0);
$start_date  = $_GET['start_date'] ?? date('Y-m-d', strtotime('-1 month'));
$end_date    = $_GET['end_date'] ?? date('Y-m-d');

$error = '';
$report_data = [];
$report_title = '';

$courseListStmt = $pdo->prepare('SELECT course_id, course_code, course_name, program FROM courses WHERE lecturer_id = ? ORDER BY course_code ASC');
$courseListStmt->execute([$lecturer_id]);
$courses = $courseListStmt->fetchAll();

$studentListStmt = $pdo->prepare('
    SELECT DISTINCT s.student_id, s.registration_number, s.full_name
    FROM students s
    WHERE s.program IN (SELECT DISTINCT program FROM courses WHERE lecturer_id = ?)
       OR s.student_id IN (
           SELECT a.student_id
           FROM attendance a
           INNER JOIN classes cl ON a.class_id = cl.class_id
           WHERE cl.lecturer_id = ?
       )
    ORDER BY s.full_name ASC
');
$studentListStmt->execute([$lecturer_id, $lecturer_id]);
$students = $studentListStmt->fetchAll();

if (isset($_GET['generate'])) {
    if ($report_type === 'course') {
        if ($course_id <= 0) {
            $error = 'Please select a course.';
        } else {
            $authStmt = $pdo->prepare('SELECT * FROM courses WHERE course_id = ? AND lecturer_id = ?');
            $authStmt->execute([$course_id, $lecturer_id]);
            $course_info = $authStmt->fetch();

            if (!$course_info) {
                $error = 'Unauthorized access to the selected course.';
            } else {
                $totalStmt = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE course_id = ? AND lecturer_id = ?');
                $totalStmt->execute([$course_id, $lecturer_id]);
                $total_classes = (int) $totalStmt->fetchColumn();

                $stmt = $pdo->prepare("
                    SELECT
                        s.student_id,
                        s.registration_number,
                        s.full_name,
                        COUNT(DISTINCT CASE WHEN c.course_id = ? AND c.lecturer_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
                    FROM students s
                    LEFT JOIN attendance a ON s.student_id = a.student_id
                    LEFT JOIN classes c ON a.class_id = c.class_id AND c.course_id = ? AND c.lecturer_id = ?
                    WHERE s.program = ? OR c.course_id = ?
                    GROUP BY s.student_id, s.registration_number, s.full_name
                    ORDER BY s.full_name ASC
                ");
                $stmt->execute([$course_id, $lecturer_id, $course_id, $lecturer_id, $course_info['program'], $course_id]);

                foreach ($stmt->fetchAll() as $r) {
                    $attended = (int) $r['attended_classes'];
                    $r['total_classes'] = $total_classes;
                    $r['attendance_percentage'] = $total_classes > 0 ? round(($attended / $total_classes) * 100, 2) : 0.0;
                    $report_data[] = $r;
                }
                $report_title = 'Course Attendance Report: ' . $course_info['course_code'] . ' - ' . $course_info['course_name'];
            }
        }
    } elseif ($report_type === 'student') {
        if ($student_id <= 0) {
            $error = 'Please select a student.';
        } else {
            $studentStmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
            $studentStmt->execute([$student_id]);
            $student_info = $studentStmt->fetch();

            if ($student_info) {
                $stmt = $pdo->prepare("
                    SELECT
                        co.course_id,
                        co.course_code,
                        co.course_name,
                        COUNT(DISTINCT c.class_id) AS total_classes,
                        COUNT(DISTINCT CASE WHEN a.student_id = ? AND a.status IN ('present', 'late') THEN c.class_id END) AS attended_classes
                    FROM courses co
                    LEFT JOIN classes c ON co.course_id = c.course_id AND c.lecturer_id = ? AND c.class_date BETWEEN ? AND ?
                    LEFT JOIN attendance a ON c.class_id = a.class_id AND a.student_id = ?
                    WHERE co.lecturer_id = ?
                    GROUP BY co.course_id, co.course_code, co.course_name
                    ORDER BY co.course_code ASC
                ");
                $stmt->execute([$student_id, $lecturer_id, $start_date, $end_date, $student_id, $lecturer_id]);

                foreach ($stmt->fetchAll() as $r) {
                    $total = (int) $r['total_classes'];
                    $attended = (int) $r['attended_classes'];
                    $r['attendance_percentage'] = $total > 0 ? round(($attended / $total) * 100, 2) : 0.0;
                    $report_data[] = $r;
                }
                $report_title = 'Student Attendance Report: ' . $student_info['full_name'] . ' (' . $student_info['registration_number'] . ')';
            }
        }
    }
}

$pageTitle = 'Lecturer Reports';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="bi bi-bar-chart-line me-2 text-primary"></i>Course &amp; Student Attendance Reports</h4>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <form method="GET" action="">
                    <div class="row g-3 mb-4">
                        <div class="col-md-3">
                            <label for="lecReportType" class="form-label">Report Type</label>
                            <select class="form-select" name="report_type" id="lecReportType">
                                <option value="course" <?php echo $report_type === 'course' ? 'selected' : ''; ?>>By My Course</option>
                                <option value="student" <?php echo $report_type === 'student' ? 'selected' : ''; ?>>By Student</option>
                            </select>
                        </div>

                        <div class="col-md-5" id="lecCourseDiv" <?php echo $report_type !== 'course' ? 'style="display:none;"' : ''; ?>>
                            <label for="course_id" class="form-label">Select Course</label>
                            <select class="form-select" name="course_id" id="course_id">
                                <option value="">-- Select Course --</option>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?php echo (int) $c['course_id']; ?>" <?php echo $course_id === (int) $c['course_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($c['course_code'] . ' - ' . $c['course_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6" id="lecStudentDiv" <?php echo $report_type !== 'student' ? 'style="display:none;"' : ''; ?>>
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <label for="student_id" class="form-label">Select Student</label>
                                    <select class="form-select" name="student_id" id="student_id">
                                        <option value="">-- Select Student --</option>
                                        <?php foreach ($students as $st): ?>
                                            <option value="<?php echo (int) $st['student_id']; ?>" <?php echo $student_id === (int) $st['student_id'] ? 'selected' : ''; ?>>
                                                <?php echo e($st['registration_number'] . ' - ' . $st['full_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="start_date" class="form-label">From</label>
                                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e($start_date); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date" class="form-label">To</label>
                                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo e($end_date); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 align-self-end">
                            <button type="submit" name="generate" value="1" class="btn btn-primary">
                                <i class="bi bi-file-earmark-bar-graph me-1"></i>Generate Report
                            </button>
                        </div>
                    </div>
                </form>

                <?php if (!empty($report_data)): ?>
                    <div class="card border mt-3">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><?php echo e($report_title); ?></h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                                <i class="bi bi-printer me-1"></i>Print Report
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <?php if ($report_type === 'course'): ?>
                                                <th>Reg No.</th>
                                                <th>Student Name</th>
                                                <th>Attended</th>
                                                <th>Total Classes</th>
                                                <th>Attendance %</th>
                                                <th>Eligibility</th>
                                            <?php else: ?>
                                                <th>Course Code</th>
                                                <th>Course Name</th>
                                                <th>Attended</th>
                                                <th>Total Classes</th>
                                                <th>Attendance %</th>
                                                <th>Eligibility</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $row): ?>
                                            <tr>
                                                <?php if ($report_type === 'course'): ?>
                                                    <td><?php echo e($row['registration_number']); ?></td>
                                                    <td><?php echo e($row['full_name']); ?></td>
                                                <?php else: ?>
                                                    <td><?php echo e($row['course_code']); ?></td>
                                                    <td><?php echo e($row['course_name']); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo (int) $row['attended_classes']; ?></td>
                                                <td><?php echo (int) $row['total_classes']; ?></td>
                                                <td><?php echo e($row['attendance_percentage']); ?>%</td>
                                                <td>
                                                    <?php if ((int) $row['total_classes'] === 0): ?>
                                                        <span class="badge bg-secondary">No Classes</span>
                                                    <?php elseif ($row['attendance_percentage'] >= 75): ?>
                                                        <span class="badge bg-success">Eligible</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">Not Eligible</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php elseif (isset($_GET['generate']) && $error === ''): ?>
                    <div class="alert alert-warning mt-3">No records found for the selected report criteria.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('lecReportType').addEventListener('change', function () {
    const type = this.value;
    document.getElementById('lecCourseDiv').style.display = (type === 'course') ? 'block' : 'none';
    document.getElementById('lecStudentDiv').style.display = (type === 'student') ? 'block' : 'none';
});
</script>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
