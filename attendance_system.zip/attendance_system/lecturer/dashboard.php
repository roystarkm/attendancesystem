<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['lecturer']);

$lecturer_id = (int) $_SESSION['user_id'];

$stmt = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE lecturer_id = ?');
$stmt->execute([$lecturer_id]);
$courses_count = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE lecturer_id = ?');
$stmt->execute([$lecturer_id]);
$classes_count = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM attendance a INNER JOIN classes c ON a.class_id = c.class_id WHERE c.lecturer_id = ?');
$stmt->execute([$lecturer_id]);
$attendance_count = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare('
    SELECT c.*, co.course_code, co.course_name
    FROM classes c
    INNER JOIN courses co ON c.course_id = co.course_id
    WHERE c.lecturer_id = ?
    ORDER BY c.class_date DESC, c.start_time DESC
    LIMIT 6
');
$stmt->execute([$lecturer_id]);
$recent_classes = $stmt->fetchAll();

$pageTitle = 'Lecturer Dashboard';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">My Courses</h5>
                    <i class="bi bi-book fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $courses_count; ?></h2>
                <a href="classes.php" class="text-white text-decoration-underline small">Schedule Classes &rarr;</a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Classes Held</h5>
                    <i class="bi bi-calendar-check fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $classes_count; ?></h2>
                <a href="classes.php" class="text-white text-decoration-underline small">Manage Sessions &rarr;</a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card bg-info text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Attendance Records</h5>
                    <i class="bi bi-clipboard-data fs-3 opacity-75"></i>
                </div>
                <h2 class="card-text my-3"><?php echo $attendance_count; ?></h2>
                <a href="reports.php" class="text-white text-decoration-underline small">View Reports &rarr;</a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="bi bi-calendar-week me-2 text-primary"></i>Recent Lecture Sessions</h5>
                <a href="classes.php" class="btn btn-sm btn-primary">
                    <i class="bi bi-plus-circle me-1"></i>Schedule Class
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Course</th>
                                <th>Time</th>
                                <th>Venue</th>
                                <th>Topic</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_classes)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-3">No classes scheduled yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_classes as $class): ?>
                                    <tr>
                                        <td><?php echo e(date('Y-m-d', strtotime($class['class_date']))); ?></td>
                                        <td><strong><?php echo e($class['course_code']); ?></strong> - <?php echo e($class['course_name']); ?></td>
                                        <td><?php echo e(date('H:i', strtotime($class['start_time'])) . ' - ' . date('H:i', strtotime($class['end_time']))); ?></td>
                                        <td><?php echo e($class['venue']); ?></td>
                                        <td><?php echo e($class['topic'] ?? '-'); ?></td>
                                        <td class="text-end">
                                            <a href="attendance.php?class_id=<?php echo (int) $class['class_id']; ?>" class="btn btn-sm btn-primary" title="Record Attendance">
                                                <i class="bi bi-clipboard-check me-1"></i>Take Attendance
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
