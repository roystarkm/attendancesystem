<?php
require_once dirname(__DIR__) . '/includes/config.php';
checkRole(['lecturer']);

$lecturer_id = (int) $_SESSION['user_id'];
$error = '';

// Handle class deletion via POST + CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_class'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid security token.');
        redirect('lecturer/classes.php');
    }

    $class_id = (int) ($_POST['class_id'] ?? 0);
    if ($class_id > 0) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM attendance WHERE class_id = ?')->execute([$class_id]);
            $stmt = $pdo->prepare('DELETE FROM classes WHERE class_id = ? AND lecturer_id = ?');
            $stmt->execute([$class_id, $lecturer_id]);
            $pdo->commit();

            logActivity("Deleted class ID: $class_id");
            setFlash('success', 'Class deleted successfully!');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('danger', 'Error deleting class: ' . $e->getMessage());
        }
    }
    redirect('lecturer/classes.php');
}

// Handle adding a new class session
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_class'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $course_id  = (int) ($_POST['course_id'] ?? 0);
        $class_date = $_POST['class_date'] ?? '';
        $start_time = $_POST['start_time'] ?? '';
        $end_time   = $_POST['end_time'] ?? '';
        $venue      = trim($_POST['venue'] ?? '');
        $topic      = trim($_POST['topic'] ?? '');

        if ($course_id <= 0 || $class_date === '' || $start_time === '' || $end_time === '' || $venue === '') {
            $error = 'Please fill in all required fields.';
        } elseif (strtotime($end_time) <= strtotime($start_time)) {
            $error = 'End time must be after start time.';
        } else {
            $verifyCourse = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE course_id = ? AND lecturer_id = ?');
            $verifyCourse->execute([$course_id, $lecturer_id]);

            if ((int) $verifyCourse->fetchColumn() === 0) {
                $error = 'You are not assigned to teach the selected course.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO classes (course_id, class_date, start_time, end_time, venue, topic, lecturer_id) VALUES (?, ?, ?, ?, ?, ?, ?)');
                if ($stmt->execute([$course_id, $class_date, $start_time, $end_time, $venue, $topic !== '' ? $topic : null, $lecturer_id])) {
                    $new_id = $pdo->lastInsertId();
                    logActivity("Added new class ID: $new_id");
                    setFlash('success', 'Class session scheduled successfully!');
                    redirect('lecturer/classes.php');
                } else {
                    $error = 'Error adding class. Please try again.';
                }
            }
        }
    }
}

$coursesStmt = $pdo->prepare('SELECT * FROM courses WHERE lecturer_id = ? ORDER BY course_code ASC');
$coursesStmt->execute([$lecturer_id]);
$courses = $coursesStmt->fetchAll();

$classesStmt = $pdo->prepare('
    SELECT c.*, co.course_code, co.course_name,
           (SELECT COUNT(*) FROM attendance a WHERE a.class_id = c.class_id) AS attendance_count
    FROM classes c
    INNER JOIN courses co ON c.course_id = co.course_id
    WHERE c.lecturer_id = ?
    ORDER BY c.class_date DESC, c.start_time DESC
');
$classesStmt->execute([$lecturer_id]);
$classes = $classesStmt->fetchAll();

$pageTitle = 'Schedule Classes';
include dirname(__DIR__) . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h4 class="card-title mb-0"><i class="bi bi-calendar-event me-2 text-primary"></i>Manage Lecture Sessions</h4>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control form-control-sm table-search" data-target="#classesTable" placeholder="Filter classes...">
                    <button class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addClassModal">
                        <i class="bi bi-plus-circle me-1"></i>Schedule Class
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped align-middle" id="classesTable">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Course</th>
                                <th>Time</th>
                                <th>Venue</th>
                                <th>Topic</th>
                                <th>Records</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($classes)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-3">No classes scheduled yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($classes as $class): ?>
                                    <tr>
                                        <td><?php echo e(date('Y-m-d', strtotime($class['class_date']))); ?></td>
                                        <td><strong><?php echo e($class['course_code']); ?></strong> - <?php echo e($class['course_name']); ?></td>
                                        <td><?php echo e(date('H:i', strtotime($class['start_time'])) . ' - ' . date('H:i', strtotime($class['end_time']))); ?></td>
                                        <td><?php echo e($class['venue']); ?></td>
                                        <td><?php echo e($class['topic'] ?? '-'); ?></td>
                                        <td><span class="badge bg-secondary"><?php echo (int) $class['attendance_count']; ?> students</span></td>
                                        <td class="text-end text-nowrap">
                                            <a href="attendance.php?class_id=<?php echo (int) $class['class_id']; ?>" class="btn btn-sm btn-primary" title="Record Attendance">
                                                <i class="bi bi-clipboard-check me-1"></i>Take Attendance
                                            </a>
                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this class and its attendance records?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="class_id" value="<?php echo (int) $class['class_id']; ?>">
                                                <button type="submit" name="delete_class" class="btn btn-sm btn-danger" title="Delete Class">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Class Modal -->
<div class="modal fade" id="addClassModal" tabindex="-1" aria-labelledby="addClassModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addClassModalLabel"><i class="bi bi-calendar-plus me-2"></i>Schedule New Class Session</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="">
                <?php echo csrfField(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="course_id" class="form-label">Course</label>
                        <select class="form-select" id="course_id" name="course_id" required>
                            <option value="">Select Course</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo (int) $course['course_id']; ?>">
                                    <?php echo e($course['course_code'] . ' - ' . $course['course_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="class_date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="class_date" name="class_date" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="start_time" name="start_time" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="end_time" name="end_time" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="venue" class="form-label">Venue</label>
                        <input type="text" class="form-control" id="venue" name="venue" placeholder="e.g. Lab 2 - Main Block" required>
                    </div>
                    <div class="mb-3">
                        <label for="topic" class="form-label">Lecture Topic (Optional)</label>
                        <input type="text" class="form-control" id="topic" name="topic" placeholder="e.g. Relational Database Design">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="add_class">
                        <i class="bi bi-check-circle me-1"></i>Save Class
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/includes/footer.php'; ?>
