document.addEventListener('DOMContentLoaded', function () {
    // Initialize Bootstrap tooltips if Bootstrap JS is available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
            new bootstrap.Tooltip(el);
        });
    }

    // Offline fallback for navbar collapse and modals if CDN Bootstrap JS is unavailable
    if (typeof bootstrap === 'undefined') {
        document.querySelectorAll('[data-bs-toggle="collapse"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const target = document.querySelector(btn.getAttribute('data-bs-target'));
                if (target) target.classList.toggle('show');
            });
        });

        document.querySelectorAll('[data-bs-toggle="modal"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const modal = document.querySelector(btn.getAttribute('data-bs-target'));
                if (modal) {
                    modal.classList.add('show');
                    modal.style.display = 'block';
                    modal.removeAttribute('aria-hidden');
                }
            });
        });

        document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const modal = btn.closest('.modal');
                if (modal) {
                    modal.classList.remove('show');
                    modal.style.display = 'none';
                    modal.setAttribute('aria-hidden', 'true');
                }
            });
        });
    }

    // Live client-side table search filter
    document.querySelectorAll('.table-search').forEach(function (input) {
        input.addEventListener('input', function () {
            const query = this.value.toLowerCase().trim();
            const table = document.querySelector(this.getAttribute('data-target'));
            if (!table) return;

            table.querySelectorAll('tbody tr').forEach(function (row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        });
    });

    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(function (button) {
        button.addEventListener('click', function () {
            const input = this.previousElementSibling;
            if (!input) return;
            const icon = this.querySelector('i');
            const isPassword = input.getAttribute('type') === 'password';
            input.setAttribute('type', isPassword ? 'text' : 'password');
            if (icon) {
                icon.classList.toggle('bi-eye', !isPassword);
                icon.classList.toggle('bi-eye-slash', isPassword);
            }
        });
    });

    // Auto-dismiss flash alerts after 5 seconds
    setTimeout(function () {
        document.querySelectorAll('.alert-dismissible').forEach(function (alert) {
            if (typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                bootstrap.Alert.getOrCreateInstance(alert).close();
            } else {
                alert.remove();
            }
        });
    }, 5000);
});

// Helper to mark all students in attendance form at once
function setAllAttendance(status) {
    document.querySelectorAll('.attendance-select').forEach(function (select) {
        select.value = status;
    });
}
