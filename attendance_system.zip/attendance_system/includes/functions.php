<?php

/**
 * Safely escape HTML output to prevent XSS.
 */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect to a path relative to BASE_URL (or an absolute URL).
 */
function redirect(string $path): void
{
    if (preg_match('#^https?://#i', $path)) {
        $target = $path;
    } else {
        $target = BASE_URL . ltrim($path, '/');
    }
    header('Location: ' . $target);
    exit();
}

/**
 * Check whether a user session is active.
 */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0;
}

/**
 * Enforce authentication and role authorization.
 */
function checkRole(array $allowedRoles): void
{
    if (!isLoggedIn()) {
        setFlash('warning', 'Please sign in to access that page.');
        redirect('login.php');
    }

    if (!in_array($_SESSION['role'] ?? '', $allowedRoles, true)) {
        setFlash('danger', 'You do not have permission to access that section.');
        if (($_SESSION['role'] ?? '') === 'admin') {
            redirect('admin/dashboard.php');
        } elseif (($_SESSION['role'] ?? '') === 'lecturer') {
            redirect('lecturer/dashboard.php');
        } else {
            redirect('login.php');
        }
    }
}

/**
 * Generate or return the active CSRF token.
 */
function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify a submitted CSRF token.
 */
function verifyCsrfToken(?string $token): bool
{
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Output a hidden CSRF token input field for HTML forms.
 */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(generateCsrfToken()) . '">';
}

/**
 * Store a flash message in the session (Post/Redirect/Get pattern).
 */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

/**
 * Retrieve and clear the current flash message.
 */
function getFlash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Record an audit log entry in system_logs.
 */
function logActivity(string $action): void
{
    global $pdo;

    try {
        $stmt = $pdo->prepare('INSERT INTO system_logs (user_id, action, ip_address) VALUES (?, ?, ?)');
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            mb_substr($action, 0, 255),
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
        ]);
    } catch (PDOException $e) {
        error_log('Activity log failed: ' . $e->getMessage());
    }
}

/**
 * Calculate a student's attendance percentage for a specific course.
 * Both 'present' and 'late' count toward attended sessions.
 */
function getAttendancePercentage(int $studentId, int $courseId): float
{
    global $pdo;

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE course_id = ?');
    $stmt->execute([$courseId]);
    $totalClasses = (int) $stmt->fetchColumn();

    if ($totalClasses === 0) {
        return 0.0;
    }

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM attendance a
        INNER JOIN classes c ON a.class_id = c.class_id
        WHERE a.student_id = ?
          AND c.course_id = ?
          AND a.status IN ('present', 'late')
    ");
    $stmt->execute([$studentId, $courseId]);
    $attended = (int) $stmt->fetchColumn();

    return round(($attended / $totalClasses) * 100, 2);
}
