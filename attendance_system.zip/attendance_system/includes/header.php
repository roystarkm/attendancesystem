<?php
$currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');
$currentDir = basename(dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? e($pageTitle) . ' - ' : ''; ?>Ndejje University - Attendance System</title>
    <link rel="icon" type="image/png" href="<?php echo e(ASSET_PATH); ?>assets/images/logo.png">
    <link rel="stylesheet" href="<?php echo e(ASSET_PATH); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(ASSET_PATH); ?>assets/css/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(ASSET_PATH); ?>assets/css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo e(ASSET_PATH); ?>index.php">
                <img src="<?php echo e(ASSET_PATH); ?>assets/images/logo.png" alt="Ndejje University Logo" height="40" class="rounded bg-white p-1">
                <span class="fw-semibold">Attendance Management System</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <?php if (isLoggedIn()): ?>
                        <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'admin' && $currentScript === 'dashboard.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>admin/dashboard.php">
                                    <i class="bi bi-speedometer2 me-1"></i>Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'admin' && in_array($currentScript, ['students.php', 'student_details.php', 'edit_student.php'], true)) ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>admin/students.php">
                                    <i class="bi bi-mortarboard me-1"></i>Manage Students
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'admin' && in_array($currentScript, ['courses.php', 'course_details.php', 'edit_course.php'], true)) ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>admin/courses.php">
                                    <i class="bi bi-book me-1"></i>Manage Courses
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'admin' && $currentScript === 'users.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>admin/users.php">
                                    <i class="bi bi-people me-1"></i>Manage Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'admin' && $currentScript === 'reports.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>admin/reports.php">
                                    <i class="bi bi-bar-chart-line me-1"></i>View Reports
                                </a>
                            </li>
                        <?php elseif (($_SESSION['role'] ?? '') === 'lecturer'): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'lecturer' && $currentScript === 'dashboard.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>lecturer/dashboard.php">
                                    <i class="bi bi-speedometer2 me-1"></i>Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'lecturer' && $currentScript === 'classes.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>lecturer/classes.php">
                                    <i class="bi bi-calendar-event me-1"></i>Schedule Classes
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'lecturer' && $currentScript === 'attendance.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>lecturer/attendance.php">
                                    <i class="bi bi-clipboard-check me-1"></i>Record Attendance
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($currentDir === 'lecturer' && $currentScript === 'reports.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>lecturer/reports.php">
                                    <i class="bi bi-bar-chart-line me-1"></i>View Reports
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentScript === 'index.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>index.php">
                                <i class="bi bi-house-door me-1"></i>Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo (strtolower($currentScript) === 'about.php') ? 'active fw-semibold' : ''; ?>" href="<?php echo e(ASSET_PATH); ?>about.php">
                                <i class="bi bi-info-circle me-1"></i>About System
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav align-items-lg-center">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item me-2">
                            <span class="nav-link text-white-50">
                                <i class="bi bi-person-circle text-white me-1"></i>
                                <strong class="text-white"><?php echo e($_SESSION['full_name'] ?? $_SESSION['username']); ?></strong>
                                <span class="badge bg-light text-primary ms-1 text-uppercase"><?php echo e($_SESSION['role'] ?? ''); ?></span>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light btn-sm" href="<?php echo e(ASSET_PATH); ?>logout.php">
                                <i class="bi bi-box-arrow-right me-1"></i>Sign Out
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-light btn-sm text-primary fw-semibold" href="<?php echo e(ASSET_PATH); ?>login.php">
                                <i class="bi bi-box-arrow-in-right me-1"></i>Sign In
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container my-4 flex-grow-1">
        <?php if ($flash): ?>
            <div class="alert alert-<?php echo e($flash['type']); ?> alert-dismissible fade show" role="alert">
                <?php echo e($flash['message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
