    </main>

    <footer class="bg-dark text-white py-4 mt-auto">
        <div class="container">
            <div class="row gy-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center mb-2">
                        <img src="<?php echo e(ASSET_PATH); ?>assets/images/logo.png" alt="Ndejje University Logo" height="36" class="rounded bg-white p-1 me-2">
                        <h5 class="mb-0">Ndejje University Attendance System</h5>
                    </div>
                    <p class="text-white-50 mb-0">Automated student attendance tracking and academic exam eligibility management.</p>
                </div>
                <div class="col-md-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="<?php echo e(ASSET_PATH); ?>index.php" class="text-white-50"><i class="bi bi-chevron-right me-1"></i>Home</a></li>
                        <li><a href="<?php echo e(ASSET_PATH); ?>about.php" class="text-white-50"><i class="bi bi-chevron-right me-1"></i>About System</a></li>
                        <li><a href="<?php echo e(ASSET_PATH); ?>login.php" class="text-white-50"><i class="bi bi-chevron-right me-1"></i>Portal Sign In</a></li>
                        <li><a href="mailto:it@ndejjeuniversity.ac.ug" class="text-white-50"><i class="bi bi-envelope me-1"></i>Contact IT Support</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Contact</h5>
                    <address class="text-white-50 small mb-0">
                        <i class="bi bi-geo-alt me-1"></i>Kampala Campus, Along Balintuma Road near Mengo Hospital<br>
                        Kampala, Uganda<br>
                        <i class="bi bi-telephone me-1"></i>+256 392 730324<br>
                        <i class="bi bi-envelope me-1"></i><a href="mailto:info@ndejjeuniversity.ac.ug" class="text-white-50">info@ndejjeuniversity.ac.ug</a>
                    </address>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="text-center text-white-50 small">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Ndejje University. All rights reserved. MATSIKO ROY, JJUUKO OSWARD &amp; SSEKABIRA ALEX.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(ASSET_PATH); ?>assets/js/script.js"></script>
</body>
</html>
