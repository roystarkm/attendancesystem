<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'attendance');
define('DB_CHARSET', 'utf8mb4');

// Determine relative path from the executing script to the application root ('' or '../')
if (!defined('ASSET_PATH')) {
    $appRoot = str_replace('\\', '/', realpath(dirname(__DIR__)));
    $scriptFile = isset($_SERVER['SCRIPT_FILENAME']) ? str_replace('\\', '/', realpath($_SERVER['SCRIPT_FILENAME'])) : '';
    $scriptDir = $scriptFile !== '' ? dirname($scriptFile) : '';

    if ($appRoot !== '' && $scriptDir !== '' && stripos($scriptDir, $appRoot) === 0) {
        $rel = trim(substr($scriptDir, strlen($appRoot)), '/');
        $depth = $rel === '' ? 0 : count(explode('/', $rel));
        define('ASSET_PATH', str_repeat('../', $depth));
    } else {
        $uriDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        if (preg_match('#/(admin|lecturer|includes)(/|$)#i', $uriDir)) {
            define('ASSET_PATH', '../');
        } else {
            define('ASSET_PATH', '');
        }
    }
}

// Dynamically determine BASE_URL so redirects and links work in any folder, host, or port
if (!defined('BASE_URL')) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);
    $scheme = $isHttps ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])) : '';
    $appRoot = str_replace('\\', '/', realpath(dirname(__DIR__)));

    if ($docRoot !== '' && $appRoot !== '' && stripos($appRoot, $docRoot) === 0) {
        $relativePath = trim(substr($appRoot, strlen($docRoot)), '/');
        $basePath = $relativePath === '' ? '/' : '/' . $relativePath . '/';
    } else {
        $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        $scriptDir = preg_replace('#/(admin|lecturer|includes)$#i', '', rtrim($scriptDir, '/'));
        $basePath = ($scriptDir === '' || $scriptDir === '/') ? '/' : $scriptDir . '/';
    }

    define('BASE_URL', $scheme . '://' . $host . $basePath);
}

// Secure session configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Create PDO database connection
try {
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(500);
    die('Database connection failed. Please verify MySQL is running and database.sql has been imported.');
}

require_once __DIR__ . '/functions.php';
